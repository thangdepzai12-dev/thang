/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View;
import Model.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Seller extends User {
    private double revenue;
    private ItemList itemlist;
    private ItemlistView itemmm;
    private Scanner sc=new Scanner(System.in);

    public Seller(String username, String password) {
        super(username, password);
        this.revenue = 0.0;
       
    }

    public Seller(ItemList itemlist, String username, String password) {
        super(username, password);
        this.itemlist = itemlist;
        this.itemmm = new ItemlistView(itemlist); 
    }
    
     public boolean checkCredentials(String inputUsername, String inputPassword) {
        return this.username.equals(inputUsername) && this.password.equals(inputPassword);
    }


    @Override
    public void login() {
        System.out.println("Seller logged in.");
    }

    @Override
    public void logout() {
        System.out.println("Seller logged out.");
    }
     public void displayAll(){
        itemlist.readfromfile("input.txt");
        itemlist.display();
    }

    public void createItem() {
      itemmm.addNewItem();
     
       }

    public void changecost(){
        itemmm.changeCost();
    }
    public void removeItem(String ir){
        itemmm.deletedbyItem();
    }
    
}
