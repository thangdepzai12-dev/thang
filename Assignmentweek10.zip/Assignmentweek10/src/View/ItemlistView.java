/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View;

import Model.Item;
import Model.ItemList;
import java.util.Scanner;

public class ItemlistView {
    private final ItemList itemlist;
    private final Scanner sc=new Scanner(System.in);

    public ItemlistView(ItemList itemlist) {
        this.itemlist = itemlist;
    }
    public void addNewItem(){
        System.out.print("Input Item:");
        String item=sc.nextLine();
        System.out.print("Input Cost:");
        double cost=sc.nextDouble();
        System.out.print("Input Have in Store:");
        int have=sc.nextInt();
        System.out.print("Input date NSX dd/yy/mmmm:");
        String date=sc.nextLine();
        Item itt=new Item(item, cost, have, date);
        if(itemlist.addNew(itt)){
            System.out.println("ADD SUCCESSFULL !");
        }
        System.out.println("ADD FALSE ! TRY AGAIN");
      } 
    public void deletedbyItem(){
        System.out.print("Input item need deleted:");
        String it=sc.nextLine();
        itemlist.removeItem(it);
    }
    public void displayAll(){
        itemlist.display();
    }
    public void changeCost(){
        System.out.print("Item :");
        String Item=sc.nextLine();
        System.out.print("New cost is:");
        double cost=sc.nextDouble();
        itemlist.updateCost(Item,cost);
    }
}
