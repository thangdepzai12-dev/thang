/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

public class ItemList {

    private ArrayList<Item> ar = new ArrayList<>();

    public ItemList() {
    }

    public ArrayList<Item> getAr() {
        return ar;
    }

    public void setAr(ArrayList<Item> ar) {
        this.ar = ar;
    }

    public boolean addNew(Item newItem) {
        for (Item cs : ar) {
            if (cs.getItem().equals(newItem.getItem())) {
                return false;
            }

        }
        ar.add(newItem);
        return true;
    }
    public void readfromfile(String filename){
        try(BufferedReader buffer=new BufferedReader(new FileReader(filename))) {
            String line;
            while((line=buffer.readLine())!=null){
                String[]parts=line.split(",");
                addNew(new Item(parts[0],Double.parseDouble(parts[1]),Integer.parseInt(parts[2]),parts[3]));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void removeItem(String it){
    ar.removeIf(c -> c.getItem().equals(it));
}
    public void display(){
        for(Item css:ar){
            System.out.println(css);
        }
    }
   
    public void updateCost(String itemName, double newCost) {
      for (Item item : ar) {
            if (item.getItem().equals(itemName)) {
                item.setCost(newCost); 
            }
        }
       

    }
     public Item searchItemByName(String itemName) {
        for (Item currentItem : ar) {
            if (currentItem.getItem().equalsIgnoreCase(itemName)) { 
                return currentItem;
            }
        }
        return null; 
    }
    public Item checkdetails(Item newItem){
        for(Item ptt:ar){
            if(ptt.getItem().equals(newItem.getItem())){
                
                return ptt;
            }
        }
        return null;
    }
}
