/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;
import java.util.ArrayList;
import java.util.Scanner;

public class Seller extends User {
    private double revenue;
    private ItemList itemlist;
    private Scanner sc=new Scanner(System.in);

    public Seller(String username, String password) {
        super(username, password);
        this.revenue = 0.0;
       
    }

    public Seller(ItemList itemlist, String username, String password) {
        super(username, password);
        this.itemlist = itemlist;
    }
    
     public boolean checkCredentials(String inputUsername, String inputPassword) {
        return this.username.equals(inputUsername) && this.password.equals(inputPassword);
    }


    @Override
    public void login() {
        System.out.println("Seller logged in.");
    }

    @Override
    public void logout() {
        System.out.println("Seller logged out.");
    }
     public void displayAll(String filename){
        filename="input.txt";
        itemlist.readfromfile(filename);
        itemlist.display();
    }

    public void createItem() {
        
      
    }

    public void changecost(String nameItem,Double Cost){
        itemlist.updateCost(nameItem,Cost);
    }
    public void removeItem(String ir){
        itemlist.removeItem(ir);
    }
    
}
