/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.Buyer;
import Model.ItemList;
import Model.Seller;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        Buyer buyer = new Buyer("buyer1", "password123");
        Seller seller = new Seller("seller1", "password123");

        while (true) {
            System.out.println("Login as (1) Buyer or (2) Seller, or (0) Exit:");
            int choice = scanner.nextInt();
            scanner.nextLine();  

            if (choice == 1) {
                 System.out.print("Enter username for Buyer: ");
                String inputUsername = scanner.nextLine();
                System.out.print("Enter password for Buyer: ");
                String inputPassword = scanner.nextLine();
                
                if (buyer.checkCredentials(inputUsername, inputPassword)) {
                    buyer.login();
                    buyerActions(buyer, scanner);
                    buyer.logout();
                } else {
                    System.out.println("Invalid username or password. Try again.");}
                    
            } else if (choice == 2) {
                    System.out.print("Enter username for Buyer: ");
                String inputUsername = scanner.nextLine();
                System.out.print("Enter password for Buyer: ");
                String inputPassword = scanner.nextLine();
                
                if (buyer.checkCredentials(inputUsername, inputPassword)) {
                    buyer.login();
                    buyerActions(buyer, scanner);
                    buyer.logout();
                } else {
                    System.out.println("Invalid username or password. Try again.");}
                    
            
            } else if (choice == 0) {
                System.out.println("Exiting system...");
                break;
            } else {
                System.out.println("Invalid choice, please try again.");
            }
        }
        
        scanner.close();
    }
      public static void buyerActions(Buyer buyer, Scanner scanner){
 
      }
    public static void sellerActions(Seller seller, Scanner scanner) {
        
    }


}
  

