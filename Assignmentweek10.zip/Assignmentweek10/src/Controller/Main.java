/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import View.Buyer;
import Model.ItemList;
import View.Seller;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        Buyer buyer = new Buyer("0", "0");
        Seller seller = new Seller("seller1", "password123");

        while (true) {
            System.out.println("Login as (1) Buyer or (2) Seller, or (0) Exit:");
            int choice = scanner.nextInt();
            scanner.nextLine();  

            if (choice == 1) {
                 System.out.print("Enter username for Buyer: ");
                String inputUsername = scanner.nextLine();
                System.out.print("Enter password for Buyer: ");
                String inputPassword = scanner.nextLine();
                
                if (buyer.checkCredentials(inputUsername, inputPassword)) {
                    buyer.login();
                    buyerActions(buyer, scanner);
                    buyer.logout();
                } else {
                    System.out.println("Invalid username or password. Try again.");}
                    
            } else if (choice == 2) {
                    System.out.print("Enter username for Buyer: ");
                String inputUsername = scanner.nextLine();
                System.out.print("Enter password for Buyer: ");
                String inputPassword = scanner.nextLine();
                
                if (buyer.checkCredentials(inputUsername, inputPassword)) {
                    buyer.login();
                    buyerActions(buyer, scanner);
                    buyer.logout();
                } else {
                    System.out.println("Invalid username or password. Try again.");}
                    
            
            } else if (choice == 0) {
                System.out.println("Exiting system...");
                break;
            } else {
                System.out.println("Invalid choice, please try again.");
            }
        }
        
        scanner.close();
    }
     public static void buyerActions(Buyer buyer, Scanner scanner) {
    int choice;
    do {
        System.out.println("Menu for Buyer");
        System.out.println("1. View All Items in Store");
        System.out.println("2. Search Item");
        System.out.println("3. Check Details");
        System.out.println("4. Exit");
        System.out.print("Enter your choice: ");
        
        choice = scanner.nextInt();
        
        switch (choice) {
            case 1:
                buyer.viewListItems();
                break;
            case 2:
                buyer.searchItem();
                break;
            case 3:
                buyer.checkdetails();
                break;
            case 4:
                System.out.println("Exiting...");
                break;
            default:
                System.out.println("Invalid choice! Please try again.");
        }
    } while (choice != 4);
}
    public static void sellerActions(Seller seller, Scanner scanner) {
        
    }


}
  

