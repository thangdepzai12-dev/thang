/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public class Item {
    private String Item;
    private double Cost;
    private int have;
    private LocalDate date;
    private DateTimeFormatter localdate=DateTimeFormatter.ofPattern("dd/MM/yyyy");

    public Item(String Item, double Cost, int have, String date) {
        this.Item = Item;
        this.Cost = Cost;
        this.have = have;
        setDate(date);
        
    }

    public String getItem() {
        return Item;
    }

    public void setItem(String Item) {
        this.Item = Item;
    }

    public double getCost() {
        return Cost;
    }

    public void setCost(double Cost) {
        this.Cost = Cost;
    }

    public int getHave() {
        return have;
    }

    public void setHave(int have) {
        this.have = have;
    }

    public String getDate() {
        return date.format(localdate);
    }

    public void setDate(String date) {
        this.date =LocalDate.parse(date,localdate);
    }

    @Override
    public String toString() {
        return String.format("Item=%-10s,Cost=%-10.2f,Have=%-10d,Date=%-15s"
                              ,Item,Cost,have,date);
    }
    
    
    
}
