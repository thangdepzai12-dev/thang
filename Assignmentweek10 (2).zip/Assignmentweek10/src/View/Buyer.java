/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View;
import Model.*;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Buyer extends User {
    private ArrayList<Item> items;
    private ItemList itemlist;
    private Scanner sc=new Scanner(System.in);
     private HashMap<String, BookingInfo> bookingMap = new HashMap<>(); 

    public Buyer(String username, String password) {
        super(username, password);
        items = new ArrayList<>();
       itemlist=new ItemList();
        
    }

    
    
     public boolean checkCredentials(String inputUsername, String inputPassword) {
        return this.username.equals(inputUsername) && this.password.equals(inputPassword);
    }


    @Override
    public void login() {
        System.out.println("Buyer logged in.");
    }

    @Override
    public void logout() {
        System.out.println("Buyer logged out.");
    }

    public void viewListItems() {
       itemlist.readfromfile("input.txt");
       itemlist.display();
        }
    public void searchItem(){
        System.out.println("Input Item need search:");
        String itemName=sc.nextLine();
        Item foundItem=itemlist.searchItemByName(itemName);
        if(foundItem!=null){
               System.out.println("Item found in store:");
               System.out.println(foundItem.getItem()); 
              } else {
        System.out.println("No item found in store with name: " + itemName);
       }
        }

    
    public void checkdetails(){
        System.out.println("Input Item need checkdetails:");
        String check =sc.nextLine();
        Item found=itemlist.searchItemByName(check);
        if(found!=null){
            System.out.println("Item have store and details is:");
            System.out.println(found);
        }
        System.out.println("No name item in store");

    }
    public void booking(){
        itemlist.displaynameItem();
        System.out.println("CHOSSE ITEM WANT TO BUY");
        String booking=sc.nextLine();
        Item book=itemlist.searchItemByName(booking);
        if(book==null){
            System.out.println("Item not in store");
        }else{
            System.out.println("Item in store continute");
        }
        
        System.out.print("Input number want to buy:");
        int number=sc.nextInt();
        double totalcost=itemlist.money(booking)*number;
        System.out.println("Money you need pay is:"+totalcost);
        sc.nextLine();
         bookingMap.put(booking, new BookingInfo(number, totalcost));

        saveAllBookingsToFile("output.txt");

        
    }
         public void saveAllBookingsToFile(String filename) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(filename, true))) {
            for (Map.Entry<String, BookingInfo> entry : bookingMap.entrySet()) {
                String itemName = entry.getKey();
                BookingInfo info = entry.getValue();
                writer.printf("Item: %s, Quantity: %d, Total Cost: %.2f, Date: %s%n",
                        itemName, info.getQuantity(), info.getTotalCost(), LocalDate.now());
            }
            System.out.println("All booking details have been recorded.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}